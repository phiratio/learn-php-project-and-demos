<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Document</title>
</head>
<body>
   
<?php 
$number = 10;
$number = 1000;

$number = "Edwin";
echo $number . "<br>";

define("NAME", 1000);

echo NAME;



    
    
    
?>
   
 
   
    
</body>
</html>