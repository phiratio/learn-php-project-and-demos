<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Document</title>
</head>
<body>
<?php


echo pow(2,7);

echo "<br>";

echo rand(1, 1000);

echo "<br>";

echo sqrt(100);

echo "<br>";

echo ceil(4.6);

echo "<br>";

echo floor(4.6);

echo "<br>";

echo round(4.5);

?>



</body>
</html>